Session.set('children1','');
Session.set('children2','');

