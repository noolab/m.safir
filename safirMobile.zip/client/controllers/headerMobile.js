var open=0;
var direction='left';
Template.headermobile.onRendered(function () {
            $('#sl2').slider();
            $(".container").hide();
            //$("#submenu-1").hide();
            $(".deroulant").hide();
});

Template.headermobile.events({
	'click .validSearch': function(e,tpl){
		var search=$("#menu-search-input-text").val();
		console.log("searching "+search);
		Session.set('keyword',search);
		Session.set('groupsearch',0);
		Router.go('searchproduct');
	},
	'click .toggle': function(e,tpl){
		$(this).toggleClass("active").next().slideToggle(350);
			return false;
	},
	'click #a-submenu-1': function(e,tpl){
		$('#submenu-1').toggle(250);
	},
	'click .sousmenu': function(e,tpl){
		var id=this._id;
		var name="#submenu-"+id;
		console.log('OUVRIR '+name);
		$(name).toggle(250);
		//$(name).attr('style','display=block;');
	},
	'click #makeup': function(e,tpl){
		$("#panel_makeup").slideToggle("slow");
	},
	'click #panel_makeup': function(e,tpl){
		$(".sub_dropdown").slideToggle("slow");
	},
	'click #price_range': function(e,tpl){
		$(".panel_price_range").slideToggle("slow");
	},
	'click #brands': function(e,tpl){
		$(".panel_brands").slideToggle("slow");
	},
	'click #advanced': function(e,tpl){
		$(".panel_advanced").slideToggle("slow");
	},
	'click #skin_type': function(e,tpl){
		$(".panel_skin_type").slideToggle("slow");
	},
	'click #a-menu': function(e,tpl){
		if(open==0){
			var from="left";
			var to="right";
			open=1;
		}
		else{
			var from="right";
			var to="left";
			open=0;
		}
		
		var cls_to = 'moved-'+to, cls_from = 'moved-'+from;
	            if (jQuery('#content-wrapper').is("."+cls_from)) {
	                jQuery('#content-wrapper').removeClass(cls_from);
	            } else if (!jQuery('#content-wrapper').is("."+cls_to)) {
	                if(cls_to == "moved-right") jQuery('#sidebar-wrapper').css("z-index", "-2");
	                if(cls_to == "moved-left") jQuery('#sidebar-wrapper').css("z-index", "0");
	                jQuery('#content-wrapper').addClass(cls_to);
	            }
	},
	'click #a-sidebar': function(e,tpl){
		
		var class_selector = 'moved-'+direction;
		if (jQuery('#content-wrapper').is("."+class_selector)) {
	                jQuery('#content-wrapper').removeClass(class_selector);

	            } else {
	                jQuery('#sidebar-wrapper').css("z-index", "-2");
	                if(class_selector == "moved-right") jQuery('#sidebar-wrapper').css("z-index", "-2");
	                if(class_selector == "moved-left") jQuery('#sidebar-wrapper').css("z-index", "0");
	                jQuery('#content-wrapper').addClass(class_selector);
	            }
	}

});

Template.headermobile.helpers({
	getParent: function(){
		return categories.find({"parent":"0"});
	},
	getChildren: function(parent){
		return categories.find({"parent":parent});
	}
});

Template.headermobile.rendered = function(){
  
};
