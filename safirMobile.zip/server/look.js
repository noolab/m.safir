Meteor.methods({
	insertLook:function(objLook){
		look.insert(objLook);
	}
});